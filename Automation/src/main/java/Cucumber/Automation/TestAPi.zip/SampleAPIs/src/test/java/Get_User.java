import static io.restassured.RestAssured.*;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNull;

import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.GetUserResponse;




public class Get_User{
	
	
	
	
    
	@Test(priority = 2)

    public void Get_A_Valid_User()

    { 	
 		//Description("Ensure that an admin can Get a Valid User")
 		
		
		int user= 3;		
		RequestSpecification reqSpecification = ReqResTestBase.getCommonReq();
		ResponseSpecification resSpecification_200 = ReqResTestBase.responseSpec_200();
		

		
		
		GetUserResponse response = given().spec(reqSpecification).pathParam("user_Id",user).when().
			
				get("/api/users/{user_Id}").then().spec(resSpecification_200).extract().response().as(GetUserResponse.class);
		
    	
		
 				assertEquals(response.getData().getId(), 3);
 				assertEquals(response.getData().getEmail(), "emma.wong@reqres.in");
 				assertEquals(response.getData().getFirst_name(), "Emma");
 				assertEquals(response.getData().getLast_name(), "Wong");
 				assertEquals(response.getData().getAvatar(), "https://reqres.in/img/faces/3-image.jpg");
 				
    }	
 				
	
	@Test(priority = 1)

    public void Get_An_Invalid_User()

    { 	
 		//Description("Ensure that an admin can Get an Invalid User")
 		
		
		int user= 3000;		
		RequestSpecification reqSpecification = ReqResTestBase.getCommonReq();
		ResponseSpecification resSpecification_404 = ReqResTestBase.responseSpec_404();
		
		GetUserResponse response = given().spec(reqSpecification).pathParam("user_Id",user).when().
			
				get("/api/users/{user_Id}").then().spec(resSpecification_404).extract().response().as(GetUserResponse.class);
		
    	
			assertNull(response.getData());
    }	
 				
	
		
		
	
	
}
