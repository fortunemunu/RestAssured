package TestBase;

import org.testng.annotations.BeforeClass;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReqResTestBase {
	
	
	
@BeforeClass
	
	

	public static RequestSpecification getCommonReq()
	{
		

	        RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder().

	                setBaseUri("https://reqres.in").
	                setContentType(ContentType.JSON).log(LogDetail.ALL);

	        

	        RequestSpecification request= requestSpecBuilder.build();
	
		return request;
		
	}


	public static ResponseSpecification responseSpec_200(){
		
		
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
				expectStatusCode(200).
				expectContentType(ContentType.JSON);
		
		ResponseSpecification response= responseSpecBuilder.build();	
		
		return response;
				
	}
	
	
	
	public static ResponseSpecification responseSpec_201(){
		
		
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
				expectStatusCode(201).
				expectContentType(ContentType.JSON);
		
		ResponseSpecification response= responseSpecBuilder.build();	
		
		return response;
				
	}

		

	
	
	public static ResponseSpecification responseSpec_404(){
		
		
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
				expectStatusCode(404).
				expectContentType(ContentType.JSON);
		
		ResponseSpecification response= responseSpecBuilder.build();	
		
		return response;
				
	}

	public static ResponseSpecification responseSpec_204(){
		
		
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
				expectStatusCode(204);
		
		ResponseSpecification response= responseSpecBuilder.build();	
		
		return response;
				
	}

		


}
