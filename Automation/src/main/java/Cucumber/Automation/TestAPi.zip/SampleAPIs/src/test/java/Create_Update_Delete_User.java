import static io.restassured.RestAssured.*;
import static org.testng.Assert.assertEquals;
import java.io.File;
import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.Create_User_Pojo;
import pojo.Update_User_Pojo;




public class Create_Update_Delete_User{
	
	
	
	
    
	@Test(priority = 1)

    public static Integer Create_A_User()

    { 	
 		//Description("Ensure that an admin can Get a Valid User")
 		
		
			
		RequestSpecification reqSpecification = ReqResTestBase.getCommonReq();
		ResponseSpecification resSpecification_201 = ReqResTestBase.responseSpec_201();
		


		File payload = new File("src/test/resources/Create_User_Payload.json");
		
		
		Create_User_Pojo response = given().spec(reqSpecification).when().body(payload).
			
				post("/api/users").then().spec(resSpecification_201).extract().response().as(Create_User_Pojo.class);
		
		
		int id = response.getId();
		
		
		
		System.out.println(id);
		
 				assertEquals(response.getName(),"Jonas");
 				assertEquals(response.getJob(), "Tester");
 				assertEquals(response.getId(), id);
 				
 		
 		return  id;
 				
    }
 		
	
	
	@Test(priority = 2)

    public void Update_A_User()

    { 	
    
    	//Description("Ensure that an admin can Update a User")
 		
		int id = Create_Update_Delete_User.Create_A_User();
		
		int User_Id = id;
			
		RequestSpecification reqSpecification = ReqResTestBase.getCommonReq();
		ResponseSpecification resSpecification_200 = ReqResTestBase.responseSpec_200();
		
	
		File payload = new File("src/test/resources/Update_User_Payload.json");
		
		
		Update_User_Pojo response = given().spec(reqSpecification).pathParam("User_ID",User_Id).when().body(payload).
			
				put("/api/users/{User_ID}").then().spec(resSpecification_200).extract().response().as(Update_User_Pojo.class);
		
		
		
 				assertEquals(response.getName(), "Mark");
 				assertEquals(response.getJob(), "Engineer");
 				
 				
 				
    }	
 			
	
	@Test(priority = 3)

    public void Delete_A_User()

    { 	
    
    	//Description("Ensure that an admin can Update a User")
 		
		int id = Create_Update_Delete_User.Create_A_User();
		
		
		int User_Id = id;
			
		RequestSpecification reqSpecification = ReqResTestBase.getCommonReq();
		ResponseSpecification resSpecification_204 = ReqResTestBase.responseSpec_204();
	

		File payload = new File("src/test/resources/Update_User_Payload.json");
		
		
		Response response = given().spec(reqSpecification).pathParam("User_ID",User_Id).when().body(payload).
			
				delete("/api/users/{User_ID}").then().spec(resSpecification_204).extract().response();
		
		
	
 				assertEquals(response.getStatusCode(), 204);
 				
 				
 				
    }	
 			
	
		
	
	
}
