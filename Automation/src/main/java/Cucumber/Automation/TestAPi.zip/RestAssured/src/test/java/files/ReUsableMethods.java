package files;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import io.restassured.path.json.JsonPath;

public class ReUsableMethods {

	public static JsonPath rawToJson(String response)
	
	{
		JsonPath js1= new JsonPath(response);
		
		return js1;
		
	}
	
	public static String generateStringFromResource(String path) throws IOException {
      return new String(Files.readAllBytes(Paths.get(path)));
}
	

}