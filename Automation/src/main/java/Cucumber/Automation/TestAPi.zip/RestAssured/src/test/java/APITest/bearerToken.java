package APITest;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import static io.restassured.RestAssured.given;

import org.testng.annotations.Test;


import files.ReUsableMethods;






public class bearerToken {
	
@Test
	

	public void loginToken ()
	{
				
		//given - all input details 
		//when - Submit the API -resource,http method
		//Then - validate the response
	
	
		RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com/accountservice";
		String response = given().log().all().header("Content-Type","application/json")
		.body("{\n"
				+ "    \"login\": \"fortune@getreliancehealth.com\",\n"
				+ "    \"password\": \"zMBTNdPa\"\n"
				+ "}")
		.when().post("/api/signin").	
		then().log().all().assertThat().statusCode(200).
		header("server", "istio-envoy").extract().response().asString();

		JsonPath js= ReUsableMethods.rawToJson(response);

		String accessToken = js.getString("access_token");
		System.out.println(accessToken);
		
		
		//List States
		RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
		given().log().all().
		header("Authorization","Bearer"+" "+accessToken).
		when().get("/tele-medicine-service/api/pharmacy-providers/states").
		then().log().all().assertThat().statusCode(200).
		header("server", "istio-envoy").extract().response().asString();
		
		
		
		
		
		
	}	
		
	
	}

