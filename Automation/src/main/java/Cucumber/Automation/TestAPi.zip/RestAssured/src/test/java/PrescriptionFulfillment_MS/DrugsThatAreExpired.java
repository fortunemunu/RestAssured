package PrescriptionFulfillment_MS;
import static io.restassured.RestAssured.given;
import org.testng.Assert;
import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;




public class DrugsThatAreExpired {
	

	
@Test
	public void filterInventoryByDrugsThatAreAboutToExpired ()

	
	     	
{
	String accessToken = Login.loginFunction();

	//Description("Ensure that a user can Filter Inventory By Expired Drugs")
	//Story("An authenticated user should be able Filter Inventory By Expired Drugs"
	RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
	String DrugsThatAreExpired = given().header("Authorization","Bearer"+" "+accessToken)
	.queryParams("providerId", "1")
	.queryParams("filter", "expired")
	.when().get("/prescription-fulfillment-service/api/drugs/filter").then().assertThat().statusCode(200).
	extract().response().asString();
	
	JsonPath js3= ReUsableMethods.rawToJson(DrugsThatAreExpired);

	String Message = js3.getString("message");

	Assert.assertTrue(Message.equals("Payload Successful"));
	
	}

}



