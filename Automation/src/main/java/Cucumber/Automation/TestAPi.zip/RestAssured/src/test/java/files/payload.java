package files;

public class payload {
	
	public static String AddPlace() {
	
	return "{\n"
			+ "  \"location\": {\n"
			+ "    \"lat\": -38.383494,\n"
			+ "    \"lng\": 33.427362\n"
			+ "  },\n"
			+ "  \"accuracy\": 50,\n"
			+ "  \"name\": \"Satellite Town\",\n"
			+ "  \"phone_number\": \"(+91) 983 893 4937\",\n"
			+ "  \"address\": \"24, side layout, cohen 09\",\n"
			+ "  \"types\": [\n"
			+ "    \"shoe park\",\n"
			+ "    \"shop\"\n"
			+ "  ],\n"
			+ "  \"website\": \"http://google.com\",\n"
			+ "  \"language\": \"French-IN\"\n"
			+ "}";

}
	
	public static String CoursePrice() 
	{
	
		return "{\n"
				+ "\n"
				+ "\"dashboard\": {\n"
				+ "\n"
				+ "\"purchaseAmount\": 1092,\n"
				+ "\n"
				+ "\"website\": \"rahulshettyacademy.com\"\n"
				+ "\n"
				+ "},\n"
				+ "\n"
				+ "\"courses\": [\n"
				+ "\n"
				+ "{\n"
				+ "\n"
				+ "\"title\": \"Selenium Python\",\n"
				+ "\n"
				+ "\"price\": 50,\n"
				+ "\n"
				+ "\"copies\": 6\n"
				+ "\n"
				+ "},\n"
				+ "\n"
				+ "{\n"
				+ "\n"
				+ "\"title\": \"Cypress\",\n"
				+ "\n"
				+ "\"price\": 40,\n"
				+ "\n"
				+ "\"copies\": 4\n"
				+ "\n"
				+ "},\n"
				+ "\n"
				+ "{\n"
				+ "\n"
				+ "\"title\": \"RPA\",\n"
				+ "\n"
				+ "\"price\": 45,\n"
				+ "\n"
				+ "\"copies\": 10\n"
				+ "\n"
				+ "},\n"
				+ "  {\n"
				+ "\n"
				+ "\"title\": \"Appium\",\n"
				+ "\n"
				+ "\"price\": 26,\n"
				+ "\n"
				+ "\"copies\": 7\n"
				+ "\n"
				+ "}\n"
				+ "\n"
				+ "]\n"
				+ "\n"
				+ "}\n"
				+ "";
		
		
	}
	
	public static String AddBook(String isbn, String aisle)
	
	{
		String  payload = "{\n"
				+ "\n"
				+ "\"name\":\"Clash of the Titan\",\n"
				+ "\"isbn\":\""+isbn+"\",\n"
				+ "\"aisle\":\""+aisle+"\",\n"
				+ "\"author\":\"Fortune Greg\"\n"
				+ "}";
		
		return payload;
	}
	
	
		public static String apiLogin()
		
		{
			String login = "\"login\": \"hackerman@gmail.com\",\n"
					+ "	    \"password\": \"Omolade123\"";
			
			return login;
			
			
		}
	
	}
	
	


