package pojoSerializeTest;

public class Types {

}
