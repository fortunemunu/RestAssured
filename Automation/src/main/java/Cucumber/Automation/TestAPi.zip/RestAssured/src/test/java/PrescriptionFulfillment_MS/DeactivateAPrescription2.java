package PrescriptionFulfillment_MS;
import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;



public class DeactivateAPrescription2 {
	

	@Test


	public void deactivateAPrescriptionUsingPrescriptionID ()

	{
	
		String accessToken = Login.loginFunction();
		
		//Description("Ensure that a user can Deactivate a Prescription Using the Prescription ID")
		//Story("An authenticated user should be able Deactivate a Prescription Using the Prescription ID")
					
		RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
		String DeactivateAPrescription = given().header("Authorization","Bearer"+" "+accessToken).pathParam("prescription Id",2)
		.when().post("/prescription-fulfillment-service/api/cancel-prescription/{prescription Id}").then().assertThat().statusCode(200).
		extract().response().asString();
				
		JsonPath js2= ReUsableMethods.rawToJson(DeactivateAPrescription);
		String Message2 = js2.getString("message");

		Assert.assertTrue(Message2.equals("Payload Successful"));
		
		//Description("Ensure that a user can Deactivate a Prescription Using Prescription ID")
		//Story("An authenticated user should be able Deactivate a Prescription Using Prescription ID")
			
		RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
		String ActivatePrescriptionUsingId = given().header("Authorization","Bearer"+" "+accessToken).pathParam("prescription Id",2)
		.when().post("/prescription-fulfillment-service/api/prescriptions/activate/{prescription Id}").then().assertThat().statusCode(200).
		extract().response().asString();
		
		JsonPath js1= ReUsableMethods.rawToJson(ActivatePrescriptionUsingId);

		String Message = js1.getString("message");

		Assert.assertTrue(Message.equals("Payload Successful"));
		
	}

}
