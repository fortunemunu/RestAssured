package PrescriptionFulfillment_MS;

public class MainTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Method K = new Method();
		
		System.out.println(K.Addition());

	}

}
