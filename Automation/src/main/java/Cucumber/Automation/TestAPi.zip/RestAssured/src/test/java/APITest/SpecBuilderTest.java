package APITest;
import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;
import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojoSerializeTest.AddPlace;
import pojoSerializeTest.Location;

public class SpecBuilderTest {
	
	@Test

	public static void main(String[] args) {
		
		
		//validate if Add Place API is workimg as expected 
		//Add place-> Update Place with New Address -> Get Place to validate if New address is present in response
		
		//given - all input details 
		//when - Submit the API -resource,http method
		//Then - validate the response
		RestAssured.baseURI= "https://rahulshettyacademy.com";
		
		AddPlace p = new AddPlace();
		p.setAccuracy(50);
		p.setAddress("23 Marina Street Lagos Island");
		p.setLanguage("English");
		p.setName("Pent House");
		p.setPhone_number("09012123456");
		p.setWebsite("www.rahulshettyacademy.com");
		List<String> myList = new ArrayList<String>();
		myList.add("shoe park");
		myList.add("shop");
		p.setTypes(myList);
		
		Location I = new Location();
		I.setLat(-38.2334);
		I.setLng(30.4555);
		
		p.setLocation(I);
		
		RequestSpecification req = new RequestSpecBuilder().setBaseUri("https://rahulshettyacademy.com").addQueryParam("key","qaclick123")
		.setContentType(ContentType.JSON).build();
		
		ResponseSpecification resspec = new ResponseSpecBuilder().expectStatusCode(200).expectContentType(ContentType.JSON).build();
		
		
		RequestSpecification res = given().spec(req).body(p);
		
		Response response = res.when().post("maps/api/place/add/json").
		then().spec(resspec).extract().response();
		
		String responseString = response.asString();
		System.out.println(responseString);
	}

}
