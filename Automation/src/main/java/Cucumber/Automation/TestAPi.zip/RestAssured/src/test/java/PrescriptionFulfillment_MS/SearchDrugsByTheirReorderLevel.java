package PrescriptionFulfillment_MS;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;
import io.restassured.path.json.JsonPath;
import files.ReUsableMethods;
import io.restassured.RestAssured;


public class SearchDrugsByTheirReorderLevel {
	

	@Test


		public void searchInventoryListOfDrugsByTheirReorderLevel ()

			{
		
			String accessToken = Login.loginFunction();
		
			//Description("Ensure that a user can Search Inventory List Of Drugs By Their Reorder Level")
			//Story("An authenticated user should be able Search Inventory List Of Drugs By Their Reorder Level"
			
				
			RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
			String DrugsByReorderLevel = given().header("Authorization","Bearer"+" "+accessToken)
			.queryParams("providerId", "1")
			.queryParams("filter", "reorder_level")
			.when().get("/prescription-fulfillment-service/api/drugs/filter").then().assertThat().statusCode(200).
			extract().response().asString();
			
			JsonPath js3= ReUsableMethods.rawToJson(DrugsByReorderLevel);

			String Message = js3.getString("message");

			Assert.assertTrue(Message.equals("Payload Successful"));
			
			}


}
