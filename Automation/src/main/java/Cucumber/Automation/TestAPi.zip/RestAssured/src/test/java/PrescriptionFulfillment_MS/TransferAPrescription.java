package PrescriptionFulfillment_MS;
import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;



public class TransferAPrescription {
	

	@Test


	public void transferAPrescription ()

	{
	
		String accessToken = Login.loginFunction();
		
		//Description("Ensure that a user can Transfer a Prescription Using the Prescription ID and Pharmacy ID")
		//Story("An authenticated user should be able Transfer a Prescription Using the Prescription ID and Pharmacy ID")
					
		RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
		String TransferAPrescription = given().header("Authorization","Bearer"+" "+accessToken).pathParam("prescription Id",1).queryParam("pharmacyId", 1)
		.when().post("/prescription-fulfillment-service/api/prescriptions/transfer/{prescription Id}").then().assertThat().statusCode(200).
		extract().response().asString();
				
		JsonPath js= ReUsableMethods.rawToJson(TransferAPrescription);
		String Message = js.getString("message");

		Assert.assertTrue(Message.equals("Payload Successful"));
		
		
		
		//Description("Ensure that a user can Transfer a Prescription Using the Prescription ID and Pharmacy ID")
		//Story("An authenticated user should be able Transfer a Prescription Using the Prescription ID and Pharmacy ID")
							
		RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
		String TransferAPrescription1 = given().header("Authorization","Bearer"+" "+accessToken).pathParam("prescription Id",1).queryParam("pharmacyId", 2)
		.when().post("/prescription-fulfillment-service/api/prescriptions/transfer/{prescription Id}").then().assertThat().statusCode(200).
		extract().response().asString();
						
		JsonPath js2= ReUsableMethods.rawToJson(TransferAPrescription1);
		String Message2 = js2.getString("message");

		Assert.assertTrue(Message2.equals("Payload Successful"));
		
		
		
	}

}
