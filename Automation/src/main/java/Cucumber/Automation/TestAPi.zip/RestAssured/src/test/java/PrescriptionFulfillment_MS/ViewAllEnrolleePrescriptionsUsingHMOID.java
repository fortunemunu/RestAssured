package PrescriptionFulfillment_MS;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;




public class ViewAllEnrolleePrescriptionsUsingHMOID {
	

	@Test


		public void searchPrescriptionUsingPrescriptionUsingHMOID ()

			{
		
			String accessToken = Login.loginFunction();
			
			//Description("Ensure that a user can View All Enrollee's Prescriptions Using HMO ID")
			//Story("An authenticated user should be able View All Enrollee's Prescriptions Using HMO ID")
				
			RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
			String ViewAllEnrolleePrescriptionUsingHMOId = given().header("Authorization","Bearer"+" "+accessToken).queryParams("hmoId", "APL/10022/A")
			.when().get("/prescription-fulfillment-service/api/prescriptions/enrollee/all").then().assertThat().statusCode(200).
			extract().response().asString();
			
			JsonPath js1= ReUsableMethods.rawToJson(ViewAllEnrolleePrescriptionUsingHMOId);

			String Message = js1.getString("message");

			Assert.assertTrue(Message.equals("Payload Successful"));
			
	     	
			}


}
