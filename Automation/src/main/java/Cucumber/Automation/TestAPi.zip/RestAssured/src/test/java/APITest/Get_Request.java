package APITest;


import org.junit.jupiter.api.Assertions;

import io.restassured.RestAssured;
import io.restassured.http.Headers;
import io.restassured.http.Method;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;


public class Get_Request {
	
	
	public static void main(String[] args) {
		
		RestAssured.baseURI = "https://bookstore.toolsqa.com";
		
		RequestSpecification httpRequest = RestAssured.given();
		
		Response response = httpRequest.request(Method.GET, "/BookStore/v1/Books");
		
		int statusCode = response.getStatusCode();
		
		Assertions.assertEquals(200,statusCode);
		
		/*
		System.out.println("Response code is " + statusCode);
		
		
		Headers header = response.getHeaders();
		System.out.println("Headers for the response are " + header);
		
		ResponseBody body = response.getBody();
		body.prettyPeek();
		System.out.println("Response Body is " + body.asString());
		*/

	}

}
