package PrescriptionFulfillment_MS;

import static io.restassured.RestAssured.given;
import org.testng.Assert;
import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;



public class DrugsAboutToExpire {
	

	
@Test
	public void filterInventoryByDrugsThatAreAboutToExpire ()
		
	
		{
		
		String accessToken = Login.loginFunction();
		
		//Description("Ensure that a user can Filter Inventory By Drugs That Are About To Expire")
	    //Story("An authenticated user should be able Filter Inventory By Drugs That Are About To Expire")
		
		RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
		String DrugsAboutToExpire = given().header("Authorization","Bearer"+" "+accessToken)
		.queryParams("providerId", "1")
		.queryParams("filter", "about_to_expire")
		.when().get("/prescription-fulfillment-service/api/drugs/filter").then().assertThat().statusCode(200).
		extract().response().asString();
		
		JsonPath js1= ReUsableMethods.rawToJson(DrugsAboutToExpire);
	
		String Message = js1.getString("message");
		Assert.assertTrue(Message.equals("Payload Successful"));
	
		}
	       
}