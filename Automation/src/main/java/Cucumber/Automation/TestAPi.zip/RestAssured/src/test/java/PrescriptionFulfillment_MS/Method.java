package PrescriptionFulfillment_MS;

public class Method {

	public int Addition()
	{
		// TODO Auto-generated method stub
		
		
		int a = 2;
		int b = 3;
		int sum;
		
		sum = a + b;
		
		
		return sum;

	}

}
