package PrescriptionFulfillment_MS;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;



public class ViewAllPrescriptionsForAllEnrollees {
	

	@Test


		public void viewAllPrescriptionForAllEnrollees ()

			{
		
			String accessToken = Login.loginFunction();
			
			//Description("Ensure that a user can View All Prescriptions For All Enrollees")
			//Story("An authenticated user should be able View All Prescriptions For All Enrollees")
			
			RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
			String ViewAllPrescriptionsForAllEnrollees = given().header("Authorization","Bearer"+" "+accessToken)
			.when().get("/prescription-fulfillment-service/api/prescriptions/all").then().assertThat().statusCode(200).
			extract().response().asString();
			
			JsonPath js1= ReUsableMethods.rawToJson(ViewAllPrescriptionsForAllEnrollees);

			String Message = js1.getString("message");
			
			Assert.assertTrue(Message.equals("Payload Successful"));
			
			
	       
	}


}
