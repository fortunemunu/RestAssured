package PrescriptionFulfillment_MS;

import static io.restassured.RestAssured.given;
import org.testng.Assert;
import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;


public class DispatchPrescriptionUsingPrescriptionID {
	

	@Test


		public void dispatchPrescriptionUsingPrescriptionID ()

			{
			
			String accessToken = Login.loginFunction();
			
			//Description("Ensure that a user can Dispatch Prescription Using Prescription ID")
			//Story("An authenticated user should be able Dispatch Prescription Using Prescription ID"
					
			RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
			String DispatchPrescriptionUsingId = given().header("Authorization","Bearer"+" "+accessToken).pathParam("prescription Id", 55)
			.when().get("prescription-fulfillment-service/api/prescriptions/dispatched/{prescription Id}").then().assertThat().statusCode(200).
			extract().response().asString();
			
			JsonPath js1= ReUsableMethods.rawToJson(DispatchPrescriptionUsingId);

			String Message = js1.getString("message");

			Assert.assertTrue(Message.equals("Payload Successful"));
			
			}


}
