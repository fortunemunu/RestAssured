package APITest;
import static io.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.List;

import org.testng.annotations.Test;
import io.restassured.RestAssured;






import io.restassured.response.Response;
import pojoSerializeTest.AddPlace;
import pojoSerializeTest.Location;

public class SerializeTest {
	
	@Test

	public static void main(String[] args) {
		
		
		//validate if Add Place API is working as expected 
		//Add place-> Update Place with New Address -> Get Place to validate if New address is present in response
		
		//given - all input details 
		//when - Submit the API -resource,http method
		//Then - validate the response
		RestAssured.baseURI= "https://rahulshettyacademy.com";
		
		AddPlace p = new AddPlace();
		p.setAccuracy(50);
		p.setAddress("23 Marina Street Lagos Island");
		p.setLanguage("English");
		p.setName("Pent House");
		p.setPhone_number("09012123456");
		p.setWebsite("www.rahulshettyacademy.com");
		List<String> myList = new ArrayList<String>();
		myList.add("shoe park");
		myList.add("shop");
		p.setTypes(myList);
		
		Location I = new Location();
		I.setLat(-38.2334);
		I.setLng(30.4555);
		
		p.setLocation(I);
		
		
		
		Response res= given().queryParam("key", "qaclick123").body(p)
		.when().post("maps/api/place/add/json").
		then().assertThat().statusCode(200).extract().response();
		
		String responseString = res.asString();
		System.out.println(responseString);
	}

}
