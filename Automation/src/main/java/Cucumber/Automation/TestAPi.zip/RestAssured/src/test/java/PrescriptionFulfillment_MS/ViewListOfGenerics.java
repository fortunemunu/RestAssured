package PrescriptionFulfillment_MS;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;



public class ViewListOfGenerics {
	

	@Test


		public void viewListOfGenerics ()

			{
		
			String accessToken = Login.loginFunction();
			
			//Description("Ensure that a user can View List Of Generics")
			//Story("An authenticated user should be able View List Of Generics")
			RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
			String ViewListOfGenerics = given().header("Authorization","Bearer"+" "+accessToken)
			.when().get("prescription-fulfillment-service/api/inventories/generics").then().assertThat().statusCode(200).
			extract().response().asString();
			
			JsonPath js1= ReUsableMethods.rawToJson(ViewListOfGenerics);

			String Message = js1.getString("message");
			
			Assert.assertTrue(Message.equals("Payload Successful"));
			
			}

}
