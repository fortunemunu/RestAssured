package PrescriptionFulfillment_MS;

import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

import org.testng.annotations.Test;


public class SampleTest{

	@Test
    public void loginFunction()

    {
        given().
        when().
        then();
    }


}

