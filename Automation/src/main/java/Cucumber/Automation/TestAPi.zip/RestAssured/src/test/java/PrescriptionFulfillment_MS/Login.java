package PrescriptionFulfillment_MS;

import static io.restassured.RestAssured.given;
import files.ReUsableMethods;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;



public class Login {
	

	public static String loginFunction ()

		{
	
		RequestSpecification rey = new RequestSpecBuilder().setBaseUri("https://dev.daara-services.reliancehmo.com/accountservice")
				.setContentType(ContentType.JSON).build();
		PojoLoginRequest pojoLogin = new PojoLoginRequest();
		pojoLogin.setLogin("fortune@getreliancehealth.com");
		pojoLogin.setPassword("zMBTNdPa");
		RequestSpecification reyLogin = given().log().all().spec(rey).body(pojoLogin);
		
		
		String AccessTokenResponse = reyLogin.when().post("/api/signin").then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath js= ReUsableMethods.rawToJson(AccessTokenResponse);
	
		String accessToken = js.getString("access_token");		
		return accessToken;
		
		}
	
	

}
