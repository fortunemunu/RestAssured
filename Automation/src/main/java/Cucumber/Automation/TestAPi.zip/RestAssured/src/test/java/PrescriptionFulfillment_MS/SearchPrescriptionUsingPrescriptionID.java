package PrescriptionFulfillment_MS;

import static io.restassured.RestAssured.given;

import org.testng.Assert;
import org.testng.annotations.Test;
import files.ReUsableMethods;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;




public class SearchPrescriptionUsingPrescriptionID {
	

	@Test


		public void searchPrescriptionUsingPrescriptionID ()

			{
		
			String accessToken = Login.loginFunction();
			
			//Description("Ensure that a user can Search Prescription Using Prescription ID")
			//Story("An authenticated user should be able Search Prescription Using Prescription ID")
				
			RestAssured.baseURI= "https://dev.daara-services.reliancehmo.com";
			String SearchPrescriptionUsingId = given().header("Authorization","Bearer"+" "+accessToken).pathParam("prescription Id", 592)
			.when().get("/prescription-fulfillment-service/api/prescriptions/{prescription Id}").then().assertThat().statusCode(200).
			extract().response().asString();
			
			JsonPath js1= ReUsableMethods.rawToJson(SearchPrescriptionUsingId);

			String Message = js1.getString("message");

			Assert.assertTrue(Message.equals("Payload Successful"));
			
			}

}


	
