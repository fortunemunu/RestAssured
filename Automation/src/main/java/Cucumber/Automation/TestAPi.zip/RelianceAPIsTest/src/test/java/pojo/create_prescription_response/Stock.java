package pojo.create_prescription_response;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@javax.annotation.processing.Generated("jsonschema2pojo")
public class Stock {

@SerializedName("id")
@Expose
private Integer id;

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

}