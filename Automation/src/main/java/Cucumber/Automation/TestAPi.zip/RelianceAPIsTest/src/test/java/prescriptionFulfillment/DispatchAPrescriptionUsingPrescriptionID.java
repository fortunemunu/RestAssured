package prescriptionFulfillment;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static org.testng.Assert.assertEquals;

import java.io.File;

import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import static org.hamcrest.MatcherAssert.assertThat;

import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import pojo.create_prescription_response.response_body;

public class DispatchAPrescriptionUsingPrescriptionID{
	
	
	@Test(priority = 1)

    public static Integer Create_A_Prescription()

    { 	
 		//Description("Ensure that a user can Create a Prescription")
 		//Story("An authenticated user should be able Create a Prescription")
			
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_2();
		//ResponseSpecification resSpecification = ReqResTestBase.resSpec_207();
		
		File prescription = new File("src/test/resources/CreatePrescriptionPayload.json");
		
		
		response_body response =  given().multiPart("prescription", prescription, "application/json").spec(reqSpecification).
				expect().defaultParser(Parser.JSON).when().post("/prescription-fulfillment-service/api/create-prescriptions").
				as(response_body.class);
	    
		
		assertEquals(response.getStatus(), "Success");
 		
		
		int Prescription_ID = response.getData().getId();
		
		
		return Prescription_ID;
		
    }
	
	
	@Test(priority = 2)

    public void Dispatch_Prescription_Using_Prescription_ID()

    { 	
 		//Description("Ensure that a Relarex Team Member can Dispatch a Prescription using the Prescription ID")
 		//Story("A Relarex Team Member can Dispatch a Prescription using the Prescription ID")
		
		
		int Prescription_Id = DispatchAPrescriptionUsingPrescriptionID.Create_A_Prescription();
		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
	
    	 
		Response response = given().spec(reqSpecification).pathParam("prescription Id",Prescription_Id).
				get("/prescription-fulfillment-service/api/prescriptions/dispatched/{prescription Id}").
 				then().spec(resSpecification).extract().response();	
    	 
  
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 		//assertThat(response.path("data.content.dispatchStatus").toString(),equalTo ("DISPATCHED"));
 		
    }


	@Test(priority = 3)

	public void Delete_A_Prescription_Using_Valid_Prescription_ID()

    { 	
 		//Description("Ensure that a user can Delete a Prescription Using a Valid Prescription ID")
 		//Story("An authenticated user should be able Delete a Prescription Using a Valid Prescription ID")
		
		int Prescription_Id = DispatchAPrescriptionUsingPrescriptionID.Create_A_Prescription();
				
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		

		Response response = given().spec(reqSpecification).pathParam("prescription Id", Prescription_Id).
				delete("/prescription-fulfillment-service/api/prescriptions/{prescription Id}").
 				then().spec(resSpecification).extract().response();	
		
		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 			
    }
	
}