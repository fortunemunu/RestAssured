package pojo.dispatch_prescription_response;


import javax.annotation.processing.Generated;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class PrescriptionAttachment {

@SerializedName("id")
@Expose
private Integer id;
@SerializedName("url")
@Expose
private String url;
@SerializedName("key")
@Expose
private String key;
@SerializedName("originalName")
@Expose
private String originalName;
@SerializedName("signedUrl")
@Expose
private String signedUrl;

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public String getUrl() {
return url;
}

public void setUrl(String url) {
this.url = url;
}

public String getKey() {
return key;
}

public void setKey(String key) {
this.key = key;
}

public String getOriginalName() {
return originalName;
}

public void setOriginalName(String originalName) {
this.originalName = originalName;
}

public String getSignedUrl() {
return signedUrl;
}

public void setSignedUrl(String signedUrl) {
this.signedUrl = signedUrl;
}

}