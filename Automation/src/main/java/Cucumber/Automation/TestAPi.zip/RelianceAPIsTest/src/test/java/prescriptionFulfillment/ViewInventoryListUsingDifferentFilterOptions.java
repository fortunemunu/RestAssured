package prescriptionFulfillment;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;
import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import static org.hamcrest.MatcherAssert.assertThat;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class ViewInventoryListUsingDifferentFilterOptions{
	
	
	@Test

	public void View_An_Inventory_List_Using_Different_Filter_Options()

    { 	
 		//Description("Ensure that a user can View an Inventory List using different Filter Options")
 		//Story("An authenticated user should be able View an Inventory List using different Filter Options")
		
		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("providerId", "1");
		queryParams.put("filter", "about_to_expire");
		queryParams.put("filter", "reorder_level");
    	 
		Response response = given().spec(reqSpecification).queryParams(queryParams).
				get("/prescription-fulfillment-service/api/drugs/filter").
 				then().spec(resSpecification).extract().response();	
	
 		
 		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 	 }	
}