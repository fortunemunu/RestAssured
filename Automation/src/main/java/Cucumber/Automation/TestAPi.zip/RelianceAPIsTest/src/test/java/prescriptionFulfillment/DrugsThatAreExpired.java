package prescriptionFulfillment;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;
import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import static org.hamcrest.MatcherAssert.assertThat;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class DrugsThatAreExpired{
	
	@Test

    public void View_Drugs_AboutAre_Expired()

    { 	
 		//Description("Ensure that a user can View Drugs that are Expired")
 		//Story("An authenticated user should be able View Drugs that are Expired")
		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("providerId", "1");
		queryParams.put("filter", "expired");
		
		Response response = given().spec(reqSpecification).queryParams(queryParams).
				get("/prescription-fulfillment-service/api/drugs/filter").
 				then().spec(resSpecification).extract().response();		
		
		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 		
    }
   	
}