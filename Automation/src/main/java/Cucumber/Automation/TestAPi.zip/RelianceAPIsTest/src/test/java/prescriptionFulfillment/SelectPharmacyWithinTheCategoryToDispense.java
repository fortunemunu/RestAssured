package prescriptionFulfillment;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;
import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import static org.hamcrest.MatcherAssert.assertThat;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class SelectPharmacyWithinTheCategoryToDispense{
	
	
	@Test

	public void Select_A_Pharmacy_With_The_Category_To_Dispense_The_Prescription()

    { 	
 		//Description("Ensure that a user can Select a Pharmacy with the Category to Dispense the Prescription")
 		//Story("An authenticated user should be able Select a Pharmacy with the Category to Dispense the Prescription")
		
		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("page", "o");
		queryParams.put("size", "5");
		queryParams.put("state", "Lagos");
		queryParams.put("longitude", "7.333");
   	 	queryParams.put("latitude", "8.52");
   	 
    	 
		Response response = given().spec(reqSpecification).queryParams(queryParams).
				get("/prescription-fulfillment-service/api/prescription/pharmacy/all").
 				then().spec(resSpecification).extract().response();	
	
 		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Book Pharmacy Payload Successful"));
 		
 		
    }	
}