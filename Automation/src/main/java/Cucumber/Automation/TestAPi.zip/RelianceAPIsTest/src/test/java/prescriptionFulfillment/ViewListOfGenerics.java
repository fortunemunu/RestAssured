package prescriptionFulfillment;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import static org.hamcrest.MatcherAssert.assertThat;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class ViewListOfGenerics{
	
	
	
	
	@Test

    public void View_List_Of_Generics()
    
    

    { 	
 		//Description("Ensure that a user can View List of Generics")
 		//Story("An authenticated user should be able View List of Generics")
		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		
    	 
		Response response = given().spec(reqSpecification).
				get("prescription-fulfillment-service/api/inventories/generics").
				then().spec(resSpecification).extract().response();				
 				
 		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 		
    }
}
