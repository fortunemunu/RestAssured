package pojo.dispatch_prescription_response;


import java.util.List;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@javax.annotation.processing.Generated("jsonschema2pojo")
public class Data {

@SerializedName("createdDate")
@Expose
private String createdDate;
@SerializedName("lastModifiedDate")
@Expose
private String lastModifiedDate;
@SerializedName("createdBy")
@Expose
private CreatedBy createdBy;
@SerializedName("lastModifiedBy")
@Expose
private LastModifiedBy lastModifiedBy;
@SerializedName("id")
@Expose
private Integer id;
@SerializedName("hmoId")
@Expose
private String hmoId;
@SerializedName("enrolleeStatus")
@Expose
private String enrolleeStatus;
@SerializedName("phoneNumber")
@Expose
private String phoneNumber;
@SerializedName("state")
@Expose
private String state;
@SerializedName("lga")
@Expose
private String lga;
@SerializedName("address")
@Expose
private String address;
@SerializedName("diagnosis")
@Expose
private String diagnosis;
@SerializedName("dueDate")
@Expose
private String dueDate;
@SerializedName("recurringStatus")
@Expose
private String recurringStatus;
@SerializedName("note")
@Expose
private String note;
@SerializedName("frequency")
@Expose
private Integer frequency;
@SerializedName("pecCheckStatus")
@Expose
private String pecCheckStatus;
@SerializedName("prescriptionCode")
@Expose
private String prescriptionCode;
@SerializedName("dispatchStatus")
@Expose
private String dispatchStatus;
@SerializedName("activeStatusType")
@Expose
private String activeStatusType;
@SerializedName("prescriptionAttachment")
@Expose
private PrescriptionAttachment prescriptionAttachment;
@SerializedName("medications")
@Expose
private List<Medication> medications = null;
@SerializedName("provider")
@Expose
private Object provider;
@SerializedName("deliveryDate")
@Expose
private Object deliveryDate;
@SerializedName("deliveryOption")
@Expose
private Object deliveryOption;

public String getCreatedDate() {
return createdDate;
}

public void setCreatedDate(String createdDate) {
this.createdDate = createdDate;
}

public String getLastModifiedDate() {
return lastModifiedDate;
}

public void setLastModifiedDate(String lastModifiedDate) {
this.lastModifiedDate = lastModifiedDate;
}

public CreatedBy getCreatedBy() {
return createdBy;
}

public void setCreatedBy(CreatedBy createdBy) {
this.createdBy = createdBy;
}

public LastModifiedBy getLastModifiedBy() {
return lastModifiedBy;
}

public void setLastModifiedBy(LastModifiedBy lastModifiedBy) {
this.lastModifiedBy = lastModifiedBy;
}

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public String getHmoId() {
return hmoId;
}

public void setHmoId(String hmoId) {
this.hmoId = hmoId;
}

public String getEnrolleeStatus() {
return enrolleeStatus;
}

public void setEnrolleeStatus(String enrolleeStatus) {
this.enrolleeStatus = enrolleeStatus;
}

public String getPhoneNumber() {
return phoneNumber;
}

public void setPhoneNumber(String phoneNumber) {
this.phoneNumber = phoneNumber;
}

public String getState() {
return state;
}

public void setState(String state) {
this.state = state;
}

public String getLga() {
return lga;
}

public void setLga(String lga) {
this.lga = lga;
}

public String getAddress() {
return address;
}

public void setAddress(String address) {
this.address = address;
}

public String getDiagnosis() {
return diagnosis;
}

public void setDiagnosis(String diagnosis) {
this.diagnosis = diagnosis;
}

public String getDueDate() {
return dueDate;
}

public void setDueDate(String dueDate) {
this.dueDate = dueDate;
}

public String getRecurringStatus() {
return recurringStatus;
}

public void setRecurringStatus(String recurringStatus) {
this.recurringStatus = recurringStatus;
}

public String getNote() {
return note;
}

public void setNote(String note) {
this.note = note;
}

public Integer getFrequency() {
return frequency;
}

public void setFrequency(Integer frequency) {
this.frequency = frequency;
}

public String getPecCheckStatus() {
return pecCheckStatus;
}

public void setPecCheckStatus(String pecCheckStatus) {
this.pecCheckStatus = pecCheckStatus;
}

public String getPrescriptionCode() {
return prescriptionCode;
}

public void setPrescriptionCode(String prescriptionCode) {
this.prescriptionCode = prescriptionCode;
}

public String getDispatchStatus() {
return dispatchStatus;
}

public void setDispatchStatus(String dispatchStatus) {
this.dispatchStatus = dispatchStatus;
}

public String getActiveStatusType() {
return activeStatusType;
}

public void setActiveStatusType(String activeStatusType) {
this.activeStatusType = activeStatusType;
}

public PrescriptionAttachment getPrescriptionAttachment() {
return prescriptionAttachment;
}

public void setPrescriptionAttachment(PrescriptionAttachment prescriptionAttachment) {
this.prescriptionAttachment = prescriptionAttachment;
}

public List<Medication> getMedications() {
return medications;
}

public void setMedications(List<Medication> medications) {
this.medications = medications;
}

public Object getProvider() {
return provider;
}

public void setProvider(Object provider) {
this.provider = provider;
}

public Object getDeliveryDate() {
return deliveryDate;
}

public void setDeliveryDate(Object deliveryDate) {
this.deliveryDate = deliveryDate;
}

public Object getDeliveryOption() {
return deliveryOption;
}

public void setDeliveryOption(Object deliveryOption) {
this.deliveryOption = deliveryOption;
}

}