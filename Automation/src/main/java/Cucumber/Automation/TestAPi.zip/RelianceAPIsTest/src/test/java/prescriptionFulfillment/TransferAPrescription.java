package prescriptionFulfillment;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;
import org.testng.annotations.Test;

import TestBase.ReqResTestBase;

import static org.hamcrest.MatcherAssert.assertThat;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class TransferAPrescription{
	
	
	
	
	
	@Test

    public void Transfer_A_Prescription_Using_Prescription_ID_And_Pharmacy_ID()

    { 	
 		//Description("Ensure that a user can Transfer a Prescription Using a Valid Prescription ID and Pharmacy ID")
 		//Story("An authenticated user should be able Transfer a Prescription Using a Valid Prescription ID and Pharmacy ID")
		
		
		
		int prescriptionId= 592;		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		

		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("providerId", "1");
	
		Response response = given().spec(reqSpecification).queryParams(queryParams).pathParam("prescription Id",prescriptionId).
				post("prescription-fulfillment-service/api/prescriptions/transfer/{prescription Id}").
 				then().spec(resSpecification).extract().response();
		
		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 		
    }
	
	

	@Test

    public void Transfer_Prescription_Using_Prescription_ID_And_Pharmacy_ID()

    { 	
 		//Description("Ensure that a user can Transfer a Prescription Using a Valid Prescription ID and Pharmacy ID")
 		//Story("An authenticated user should be able Transfer a Prescription Using a Valid Prescription ID and Pharmacy ID")
    	 
		int prescriptionId= 592;		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		

		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("providerId", "2");
		 
		Response response = given().spec(reqSpecification).queryParams(queryParams).pathParam("prescription Id",prescriptionId).
				post("prescription-fulfillment-service/api/prescriptions/transfer/{prescription Id}").
 				
 				then().spec(resSpecification).extract().response();
		 
		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 		
    }	
}
