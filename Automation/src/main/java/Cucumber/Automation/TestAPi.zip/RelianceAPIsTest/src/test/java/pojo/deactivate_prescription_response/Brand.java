package pojo.deactivate_prescription_response;



import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@javax.annotation.processing.Generated("jsonschema2pojo")
public class Brand {

@SerializedName("createdDate")
@Expose
private String createdDate;
@SerializedName("lastModifiedDate")
@Expose
private String lastModifiedDate;
@SerializedName("id")
@Expose
private Integer id;
@SerializedName("name")
@Expose
private String name;
@SerializedName("inventoryBrand")
@Expose
private InventoryBrand inventoryBrand;

public String getCreatedDate() {
return createdDate;
}

public void setCreatedDate(String createdDate) {
this.createdDate = createdDate;
}

public String getLastModifiedDate() {
return lastModifiedDate;
}

public void setLastModifiedDate(String lastModifiedDate) {
this.lastModifiedDate = lastModifiedDate;
}

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}

public InventoryBrand getInventoryBrand() {
return inventoryBrand;
}

public void setInventoryBrand(InventoryBrand inventoryBrand) {
this.inventoryBrand = inventoryBrand;
}

}