package TestBase;

import org.testng.annotations.BeforeClass;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.http.ContentType;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class ReqResTestBase {
	
	
	
	@BeforeClass
	
	
	public static RequestSpecification reqSpec_1()
	
	{
		String accessToken = Login.loginFunction();
		
		RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder().

	          setBaseUri("https://dev.daara-services.reliancehmo.com").
	          addHeader("Authorization","Bearer"+" "+accessToken).
	          setContentType(ContentType.JSON).log(LogDetail.ALL);

	        RequestSpecification request= requestSpecBuilder.build();
	        return request;
	}


	public static RequestSpecification reqSpec_2()
	
	{
		String accessToken = Login.loginFunction();
		
		RequestSpecBuilder requestSpecBuilder = new RequestSpecBuilder().
	
	    setBaseUri("https://dev.daara-services.reliancehmo.com").
	    addHeader("Authorization","Bearer"+" "+accessToken).log(LogDetail.ALL);
	
		RequestSpecification request= requestSpecBuilder.build();
		return request;
	
	}
	

	public static ResponseSpecification resSpec_200()
	
	{		
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
		expectStatusCode(200).expectContentType(ContentType.JSON).log(LogDetail.ALL);
			
		ResponseSpecification response= responseSpecBuilder.build();	
		return response;
					
	}
	
	
	public static ResponseSpecification resSpec_201()
	
	{
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
		expectStatusCode(201).expectContentType(ContentType.JSON).log(LogDetail.ALL);
			
		ResponseSpecification response= responseSpecBuilder.build();	
		return response;			
	}
	
	
	public static ResponseSpecification resSpec_404()
	
	{		
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
		expectStatusCode(404).expectContentType(ContentType.JSON).log(LogDetail.ALL);
			
		ResponseSpecification response= responseSpecBuilder.build();	
		return response;				
	}
	
	
	public static ResponseSpecification resSpec_400()
	
	{
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
		expectStatusCode(400).expectContentType(ContentType.JSON).log(LogDetail.ALL);
		
		ResponseSpecification response= responseSpecBuilder.build();	
		return response;			
	}
	
	
	public static ResponseSpecification resSpec_500()
	
	{
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
		expectStatusCode(500).expectContentType(ContentType.JSON).log(LogDetail.ALL);
			
		ResponseSpecification response= responseSpecBuilder.build();	
		return response;			
	}
		

	public static ResponseSpecification resSpec_207()
		
	{	
		ResponseSpecBuilder responseSpecBuilder = new ResponseSpecBuilder().
		expectStatusCode(207).log(LogDetail.ALL);
			
		ResponseSpecification response= responseSpecBuilder.build();	
		return response;				
	}


}
