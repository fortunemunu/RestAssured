package pojo.deactivate_prescription_response;







import java.util.List;

import javax.annotation.processing.Generated;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class deactivate_response_body {

@SerializedName("status")
@Expose
private String status;
@SerializedName("message")
@Expose
private String message;
@SerializedName("data")
@Expose
private Data data;
@SerializedName("partialErrors")
@Expose
private List<String> partialErrors = null;

public String getStatus() {
return status;
}

public void setStatus(String status) {
this.status = status;
}

public String getMessage() {
return message;
}

public void setMessage(String message) {
this.message = message;
}

public Data getData() {
return data;
}

public void setData(Data data) {
this.data = data;
}

public List<String> getPartialErrors() {
return partialErrors;
}

public void setPartialErrors(List<String> partialErrors) {
this.partialErrors = partialErrors;
}

}