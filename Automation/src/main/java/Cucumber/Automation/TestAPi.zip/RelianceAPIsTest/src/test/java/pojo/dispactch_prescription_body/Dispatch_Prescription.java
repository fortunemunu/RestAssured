package pojo.dispactch_prescription_body;

import javax.annotation.processing.Generated;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Dispatch_Prescription {

@SerializedName("prescriptionCode")
@Expose
private String prescriptionCode;
@SerializedName("dispatchStatus")
@Expose
private String dispatchStatus;

public String getPrescriptionCode() {
return prescriptionCode;
}

public void setPrescriptionCode(String prescriptionCode) {
this.prescriptionCode = prescriptionCode;
}

public String getDispatchStatus() {
return dispatchStatus;
}

public void setDispatchStatus(String dispatchStatus) {
this.dispatchStatus = dispatchStatus;
}

}