package pojo.deactivate_prescription_response;


import javax.annotation.processing.Generated;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class DrugForm {

@SerializedName("createdDate")
@Expose
private String createdDate;
@SerializedName("lastModifiedDate")
@Expose
private String lastModifiedDate;
@SerializedName("createdBy")
@Expose
private CreatedBy__1 createdBy;
@SerializedName("lastModifiedBy")
@Expose
private LastModifiedBy__1 lastModifiedBy;
@SerializedName("id")
@Expose
private Integer id;
@SerializedName("name")
@Expose
private String name;
@SerializedName("code")
@Expose
private String code;
@SerializedName("dosage")
@Expose
private String dosage;
@SerializedName("durationType")
@Expose
private String durationType;
@SerializedName("minAge")
@Expose
private Integer minAge;
@SerializedName("maxAge")
@Expose
private Integer maxAge;
@SerializedName("stock")
@Expose
private Stock stock;
@SerializedName("brand")
@Expose
private Brand brand;

public String getCreatedDate() {
return createdDate;
}

public void setCreatedDate(String createdDate) {
this.createdDate = createdDate;
}

public String getLastModifiedDate() {
return lastModifiedDate;
}

public void setLastModifiedDate(String lastModifiedDate) {
this.lastModifiedDate = lastModifiedDate;
}

public CreatedBy__1 getCreatedBy() {
return createdBy;
}

public void setCreatedBy(CreatedBy__1 createdBy) {
this.createdBy = createdBy;
}

public LastModifiedBy__1 getLastModifiedBy() {
return lastModifiedBy;
}

public void setLastModifiedBy(LastModifiedBy__1 lastModifiedBy) {
this.lastModifiedBy = lastModifiedBy;
}

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}

public String getCode() {
return code;
}

public void setCode(String code) {
this.code = code;
}

public String getDosage() {
return dosage;
}

public void setDosage(String dosage) {
this.dosage = dosage;
}

public String getDurationType() {
return durationType;
}

public void setDurationType(String durationType) {
this.durationType = durationType;
}

public Integer getMinAge() {
return minAge;
}

public void setMinAge(Integer minAge) {
this.minAge = minAge;
}

public Integer getMaxAge() {
return maxAge;
}

public void setMaxAge(Integer maxAge) {
this.maxAge = maxAge;
}

public Stock getStock() {
return stock;
}

public void setStock(Stock stock) {
this.stock = stock;
}

public Brand getBrand() {
return brand;
}

public void setBrand(Brand brand) {
this.brand = brand;
}

}