package pojo.deactivate_prescription_response;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@javax.annotation.processing.Generated("jsonschema2pojo")
public class Prescription {

@SerializedName("createdDate")
@Expose
private String createdDate;
@SerializedName("lastModifiedDate")
@Expose
private String lastModifiedDate;
@SerializedName("createdBy")
@Expose
private Object createdBy;
@SerializedName("lastModifiedBy")
@Expose
private Object lastModifiedBy;
@SerializedName("id")
@Expose
private Integer id;
@SerializedName("hmoId")
@Expose
private Object hmoId;
@SerializedName("enrolleeStatus")
@Expose
private Object enrolleeStatus;
@SerializedName("phoneNumber")
@Expose
private Object phoneNumber;
@SerializedName("state")
@Expose
private Object state;
@SerializedName("lga")
@Expose
private Object lga;
@SerializedName("address")
@Expose
private Object address;
@SerializedName("diagnosis")
@Expose
private Object diagnosis;
@SerializedName("dueDate")
@Expose
private Object dueDate;
@SerializedName("recurringStatus")
@Expose
private Object recurringStatus;
@SerializedName("note")
@Expose
private Object note;
@SerializedName("frequency")
@Expose
private Object frequency;
@SerializedName("pecCheckStatus")
@Expose
private Object pecCheckStatus;
@SerializedName("prescriptionCode")
@Expose
private Object prescriptionCode;
@SerializedName("dispatchStatus")
@Expose
private Object dispatchStatus;
@SerializedName("activeStatusType")
@Expose
private Object activeStatusType;
@SerializedName("prescriptionAttachment")
@Expose
private Object prescriptionAttachment;
@SerializedName("medications")
@Expose
private Object medications;
@SerializedName("provider")
@Expose
private Object provider;
@SerializedName("deliveryDate")
@Expose
private Object deliveryDate;
@SerializedName("deliveryOption")
@Expose
private Object deliveryOption;

public String getCreatedDate() {
return createdDate;
}

public void setCreatedDate(String createdDate) {
this.createdDate = createdDate;
}

public String getLastModifiedDate() {
return lastModifiedDate;
}

public void setLastModifiedDate(String lastModifiedDate) {
this.lastModifiedDate = lastModifiedDate;
}

public Object getCreatedBy() {
return createdBy;
}

public void setCreatedBy(Object createdBy) {
this.createdBy = createdBy;
}

public Object getLastModifiedBy() {
return lastModifiedBy;
}

public void setLastModifiedBy(Object lastModifiedBy) {
this.lastModifiedBy = lastModifiedBy;
}

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public Object getHmoId() {
return hmoId;
}

public void setHmoId(Object hmoId) {
this.hmoId = hmoId;
}

public Object getEnrolleeStatus() {
return enrolleeStatus;
}

public void setEnrolleeStatus(Object enrolleeStatus) {
this.enrolleeStatus = enrolleeStatus;
}

public Object getPhoneNumber() {
return phoneNumber;
}

public void setPhoneNumber(Object phoneNumber) {
this.phoneNumber = phoneNumber;
}

public Object getState() {
return state;
}

public void setState(Object state) {
this.state = state;
}

public Object getLga() {
return lga;
}

public void setLga(Object lga) {
this.lga = lga;
}

public Object getAddress() {
return address;
}

public void setAddress(Object address) {
this.address = address;
}

public Object getDiagnosis() {
return diagnosis;
}

public void setDiagnosis(Object diagnosis) {
this.diagnosis = diagnosis;
}

public Object getDueDate() {
return dueDate;
}

public void setDueDate(Object dueDate) {
this.dueDate = dueDate;
}

public Object getRecurringStatus() {
return recurringStatus;
}

public void setRecurringStatus(Object recurringStatus) {
this.recurringStatus = recurringStatus;
}

public Object getNote() {
return note;
}

public void setNote(Object note) {
this.note = note;
}

public Object getFrequency() {
return frequency;
}

public void setFrequency(Object frequency) {
this.frequency = frequency;
}

public Object getPecCheckStatus() {
return pecCheckStatus;
}

public void setPecCheckStatus(Object pecCheckStatus) {
this.pecCheckStatus = pecCheckStatus;
}

public Object getPrescriptionCode() {
return prescriptionCode;
}

public void setPrescriptionCode(Object prescriptionCode) {
this.prescriptionCode = prescriptionCode;
}

public Object getDispatchStatus() {
return dispatchStatus;
}

public void setDispatchStatus(Object dispatchStatus) {
this.dispatchStatus = dispatchStatus;
}

public Object getActiveStatusType() {
return activeStatusType;
}

public void setActiveStatusType(Object activeStatusType) {
this.activeStatusType = activeStatusType;
}

public Object getPrescriptionAttachment() {
return prescriptionAttachment;
}

public void setPrescriptionAttachment(Object prescriptionAttachment) {
this.prescriptionAttachment = prescriptionAttachment;
}

public Object getMedications() {
return medications;
}

public void setMedications(Object medications) {
this.medications = medications;
}

public Object getProvider() {
return provider;
}

public void setProvider(Object provider) {
this.provider = provider;
}

public Object getDeliveryDate() {
return deliveryDate;
}

public void setDeliveryDate(Object deliveryDate) {
this.deliveryDate = deliveryDate;
}

public Object getDeliveryOption() {
return deliveryOption;
}

public void setDeliveryOption(Object deliveryOption) {
this.deliveryOption = deliveryOption;
}

}