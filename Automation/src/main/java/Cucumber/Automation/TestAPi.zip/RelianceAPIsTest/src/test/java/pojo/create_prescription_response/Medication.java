package pojo.create_prescription_response;

import javax.annotation.processing.Generated;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Medication {

@SerializedName("id")
@Expose
private Integer id;
@SerializedName("dosage")
@Expose
private String dosage;
@SerializedName("frequency")
@Expose
private String frequency;
@SerializedName("duration")
@Expose
private String duration;
@SerializedName("quantity")
@Expose
private String quantity;
@SerializedName("comment")
@Expose
private String comment;
@SerializedName("price")
@Expose
private Double price;
@SerializedName("drugType")
@Expose
private String drugType;
@SerializedName("prescription")
@Expose
private Prescription prescription;
@SerializedName("drugForm")
@Expose
private DrugForm drugForm;

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public String getDosage() {
return dosage;
}

public void setDosage(String dosage) {
this.dosage = dosage;
}

public String getFrequency() {
return frequency;
}

public void setFrequency(String frequency) {
this.frequency = frequency;
}

public String getDuration() {
return duration;
}

public void setDuration(String duration) {
this.duration = duration;
}

public String getQuantity() {
return quantity;
}

public void setQuantity(String quantity) {
this.quantity = quantity;
}

public String getComment() {
return comment;
}

public void setComment(String comment) {
this.comment = comment;
}

public Double getPrice() {
return price;
}

public void setPrice(Double price) {
this.price = price;
}

public String getDrugType() {
return drugType;
}

public void setDrugType(String drugType) {
this.drugType = drugType;
}

public Prescription getPrescription() {
return prescription;
}

public void setPrescription(Prescription prescription) {
this.prescription = prescription;
}

public DrugForm getDrugForm() {
return drugForm;
}

public void setDrugForm(DrugForm drugForm) {
this.drugForm = drugForm;
}

}