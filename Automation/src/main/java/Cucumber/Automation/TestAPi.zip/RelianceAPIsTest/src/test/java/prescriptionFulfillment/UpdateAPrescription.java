package prescriptionFulfillment;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import java.io.File;
import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import static org.hamcrest.MatcherAssert.assertThat;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class UpdateAPrescription{
	
	
	
	
	@Test

    public void Update_Prescription()

    { 	
 		//Description("Ensure that a user can Edit Update a Prescription")
 		//Story("An authenticated user should be able Edit Update a Prescription")
		
		
		int prescriptionId= 6363;		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		
		File payload = new File("src/test/resources/UpdatePrescriptionPayload.json");
		
    	 
		Response response = given().spec(reqSpecification).pathParam("prescription Id",prescriptionId).body(payload).
				put("/prescription-fulfillment-service/api/prescriptions/{prescription Id}").
				then().spec(resSpecification).extract().response();
		
  		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 		
    }	
}