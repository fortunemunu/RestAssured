package pojo.create_prescription_response;


import javax.annotation.processing.Generated;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class InventoryBrand {

@SerializedName("createdDate")
@Expose
private String createdDate;
@SerializedName("lastModifiedDate")
@Expose
private String lastModifiedDate;
@SerializedName("id")
@Expose
private Integer id;
@SerializedName("generic")
@Expose
private String generic;

public String getCreatedDate() {
return createdDate;
}

public void setCreatedDate(String createdDate) {
this.createdDate = createdDate;
}

public String getLastModifiedDate() {
return lastModifiedDate;
}

public void setLastModifiedDate(String lastModifiedDate) {
this.lastModifiedDate = lastModifiedDate;
}

public Integer getId() {
return id;
}

public void setId(Integer id) {
this.id = id;
}

public String getGeneric() {
return generic;
}

public void setGeneric(String generic) {
this.generic = generic;
}

}


