package prescriptionFulfillment;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import static org.hamcrest.MatcherAssert.assertThat;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class ViewAllPrescriptionsForAllEnrollees{
	
	
	 
	@Test

    public void View_All_Prescriptions_For_All_Enrollees()
    
 
    { 	
 		//Description("Ensure that a user can View all Prescription for all Enrollees")
 		//Story("An authenticated user should be able View all Prescription for all Enrollees")
		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		
		Response response = given().spec(reqSpecification).get("/prescription-fulfillment-service/api/prescriptions/all").
 				then().spec(resSpecification).extract().response();	
 				
 		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 			
    }
}
