package TestBase;
import static io.restassured.RestAssured.given;

import java.io.File;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.specification.RequestSpecification;



public class Login {
	

	public static String loginFunction ()

		{
		
		File payload = new File("src/test/resources/LoginPayLoad.json");
		
	
		RequestSpecification rey = new RequestSpecBuilder().setBaseUri("https://dev.daara-services.reliancehmo.com/accountservice")
				.setContentType(ContentType.JSON).build();
		
		RequestSpecification reyLogin = given().log().all().spec(rey).body(payload);
		
		
		String AccessTokenResponse = reyLogin.when().post("/api/signin").then().log().all().assertThat().statusCode(200).extract().response().asString();
		JsonPath js= ReUsableMethods.rawToJson(AccessTokenResponse);
	
		String accessToken = js.getString("access_token");		
		return accessToken;
		
		}
	
	

}
