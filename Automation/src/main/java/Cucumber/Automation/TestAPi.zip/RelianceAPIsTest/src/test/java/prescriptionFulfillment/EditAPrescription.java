package prescriptionFulfillment;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import java.io.File;
import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import static org.hamcrest.MatcherAssert.assertThat;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

public class EditAPrescription{
	
	
	@Test

    public void Edit_A_Prescription_Using_Valid_Prescription_ID()

    { 	
 		//Description("Ensure that a user can Edit a Prescription Using a Valid Prescription ID")
 		//Story("An authenticated user should be able Edit a Prescription Using a Valid Prescription ID")
		
		
		int prescriptionId= 6339;		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		
		
		File payload = new File("src/test/resources/EditPrescriptionPayload.json");
		 
		Response response = given().spec(reqSpecification).pathParam("prescription Id",prescriptionId).body(payload).
				patch("/prescription-fulfillment-service/api/prescriptions/{prescription Id}").
 				then().spec(resSpecification).extract().response();
		
  		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 		
    }	
}
