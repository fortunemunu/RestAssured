package prescriptionFulfillment;
import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import java.util.HashMap;
import org.testng.annotations.Test;
import TestBase.ReqResTestBase;
import static org.hamcrest.MatcherAssert.assertThat;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;


public class PaginateResponse{
	
	
	
	
	
	@Test

    public void Paginate_A_List_Of_Prescriptions()

    { 	
 		//Description("Ensure that a user can Paginate a List of Prescriptions")
 		//Story("An authenticated user should be able Paginate a List of Prescriptions")
		
		
		RequestSpecification reqSpecification = ReqResTestBase.reqSpec_1();
		ResponseSpecification resSpecification = ReqResTestBase.resSpec_200();
		
		HashMap<String, String> queryParams = new HashMap<>();
		queryParams.put("number", "1");
		queryParams.put("size", "2");	
			
    	 
		Response response = given().spec(reqSpecification).queryParams(queryParams).
				get("prescription-fulfillment-service/api/prescriptions").
 				then().spec(resSpecification).extract().response();	
 		
 		assertThat(response.path("status").toString(),equalTo ("Success"));
 		assertThat(response.path("message").toString(),equalTo ("Payload Successful"));
 		
    }	
}