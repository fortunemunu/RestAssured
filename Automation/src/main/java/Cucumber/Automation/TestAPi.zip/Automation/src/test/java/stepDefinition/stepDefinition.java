package stepDefinition;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class stepDefinition {
	
	@Given("^User is on NetBanking landing page$")
	public void User_is_on_NetBanking_landing_page()
	{
	
		//Code for user to navigate to the landing page
		
	}
	
	@When("^User logs in into the application with user name and password$")
	public void User_logs_in_into_the_application_with_user_name_and_password()
	{
	
		
		
	}
	
	@Then("^Home page is populated$")
	public void Home_page_is_populated()
	{
	
		
		
	}
	
	@And("^Cards are displayed$")
	public void Cards_are_displayed()
	{
	
		
		
	}

}


